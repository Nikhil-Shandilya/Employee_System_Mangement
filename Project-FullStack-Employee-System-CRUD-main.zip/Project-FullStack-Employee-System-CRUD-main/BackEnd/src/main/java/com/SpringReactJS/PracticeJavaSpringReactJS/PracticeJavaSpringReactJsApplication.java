package com.SpringReactJS.PracticeJavaSpringReactJS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeJavaSpringReactJsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeJavaSpringReactJsApplication.class, args);
	}

}
