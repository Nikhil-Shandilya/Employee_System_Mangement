package com.SpringReactJS.PracticeJavaSpringReactJS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeJavaSpringReactJsApplicationTests {

	@Test
	void contextLoads() {
	}

}
